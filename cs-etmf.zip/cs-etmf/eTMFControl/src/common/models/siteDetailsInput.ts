export interface ISiteDetailsInput {
    SiteNo?: string;
    FirstName?: string;
    LastName?: string;
    Address1?: string;
    CityState?: string;
    Country?: string[];
}