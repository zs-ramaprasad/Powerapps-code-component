export class IBaseOutput {
    BaseCode: number;
    BaseMessage: string;
}